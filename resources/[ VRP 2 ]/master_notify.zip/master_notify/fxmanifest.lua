fx_version "bodacious"
game "gta5"

ui_page "web-side/index.html"

client_scripts {
	"@vrp/lib/utils.lua",
	"client-side/*"
}

files {
	"web-side/*",
	"web-side/images/*"
}

----https://discord.gg/Xg8cZhcPbT